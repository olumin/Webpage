<!DOCTYPE html>
<html prefix="og: http://ogp.me/ns#" lang="en-US" dir="ltr">

<head><link rel="stylesheet" href="https://templates.microweber.com/banking/userfiles/modules/microweber/default.css" type="text/css" />
<script src="https://templates.microweber.com/banking/userfiles/cache/apijs_combined/api.combined.1565262623.public.1.3.1.js"></script>

<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <title>Microweber</title>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta property="og:title" content="Microweber">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://templates.microweber.com/banking/icon_selector.js">
    <meta property="og:image" content="">
    <meta property="og:description" content="">
    <meta property="og:site_name" content="Microweber">
    <link href="https://fonts.cdnfonts.com/css/milliard" rel="stylesheet">

    <script>
        mw.require('icon_selector.js');
        mw.lib.require('bootstrap5js');
        mw.require('https://templates.microweber.com/banking/userfiles/templates/banking/assets/plugins/mw-ui/assets/ui/plugins/js/plugins.js');
        mw.lib.require('bxslider');
        mw.lib.require('slick');
        mw.iconLoader()
            .addIconSet('iconsMindLine')
            .addIconSet('iconsMindSolid')
            .addIconSet('fontAwesome')
            .addIconSet('materialDesignIcons')
    </script>



    <link href="https://templates.microweber.com/banking/userfiles/media/default/css/banking/assets/css/colors.scss.1.3.1-5.2.css?t=1665577093" id="theme-style" rel="stylesheet" type="text/css" media="all">
    <link href="https://templates.microweber.com/banking/userfiles/templates/banking/assets/css/main.css" rel="stylesheet">
    <link href="https://templates.microweber.com/banking/userfiles/templates/banking/assets/templates_features/css/scss/styles-for-template.css" rel="stylesheet">
    <script src="https://templates.microweber.com/banking/userfiles/templates/banking/assets/templates_features/js/js-for-template.js"></script>


    
<script id="template-animations-data">mw.__pageAnimations = []</script>
<link rel="stylesheet" href="https://templates.microweber.com/banking/userfiles/css/banking/live_edit.css?version=1665577093" id="mw-template-settings" type="text/css" /><link rel="stylesheet" href="https://templates.microweber.com/banking/userfiles/css/banking/live_edit.css?version=1665577093" id="mw-template-settings" type="text/css" />
<meta name="generator" content="Microweber" />
</head>
<body>
<!--<body class="--><!-- --><!-- ">-->


<div class="main">
    <div class="navigation-holder">
        <div class=' module module-layouts '   data-mw-title="Layouts" template="menus/skin-1"   template-filter="menus"   id="header-layout"   data-type="layouts"   parent-module="layouts"   parent-module-id="header-layout"  >
<section class="header-background">
    

    <nav class="navbar navbar-expand-xl navbar-light   header-style-3">
        <div class="container-fluid px-0 px-xl-5 justify-content-center">
            <div class="row col-12 d-flex justify-content-center ">
                <div class="d-block d-xl-none col-lg-4 py-2 mw-big-navbar-toggler order-3 order-lg-1 d-flex justify-content-center">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="mdi mdi-text header-menu-toggle-button"></span>
                    </button>

                </div>
                <div class='d-flex me-lg-auto col-auto col-lg-4 mw-big-header-logo w-auto align-self-center  my-md-0 my-1 module module-logo '   data-mw-title="Logo" id="header-logo-header-layout"   parent-module-id="header-layout"   parent-module="layouts"   data-type="logo"  >

<a href="https://templates.microweber.com/banking/" class="navbar-brand me-0">
                    <script>
            mw.lib.require('fitty');

            $(document).ready(function () {
                //fitty(document.getElementById('fitty-header-logo-header-layout-1'));
                //fitty(document.getElementById('fitty-header-logo-header-layout-2'));
            });
        </script>
    

                <div class="logo logo-light">
                    <span class="logo-text">
                        <span
                            id="fitty-header-logo-header-layout-2"
                            style="font-family: inherit;font-size:14px;">
                            <span class="mw-richtext-cssApplier" style="font-size:18px;"></span><span class="mw-richtext-cssApplier" style="font-size:16px;"><span class="mw-richtext-cssApplier" style="font-size:18px;"><font color="#000000"><b><span class="mw-richtext-cssApplier" style="font-size:20px;"></span><span class="mw-richtext-cssApplier" style="font-size:24px;"><span class="mw-richtext-cssApplier" style="font-size:20px;">BANKING</span></span></b></font></span></span>                        </span>
                    </span>
                </div>
        </a>
</div>

                <div class="col-lg-4 col-12 d-flex mx-md-0 mx-auto justify-content-center order-3 order-xl-2">
                    <div class="collapse navbar-collapse top-0 bottom-0 justify-content-center" id="navbarSupportedContent" style="z-index: 9;">
                        <div class='nav-holder module module-menu '   data-mw-title="Menu" name="header_menu"   id="header_menu"   template="navbar"   parent-module-id="header-layout"   parent-module="layouts"   data-type="menu"  >

<ul role="menu"  id=""  class="navbar-nav menu_1  menu-root menu-item-id-2 menu-item-parent-1" ><li role="menuitem" class="nav-item   dropdown depth-0" data-item-id="2" ><a itemprop="url" data-item-id="2" href="#"  role="button" data-toggle="dropdown" class="menu_element_link   menu-root menu-item-id-2 menu-item-parent-1 depth-0 nav-link px-3 dropdown-toggle" aria-haspopup="true" aria-expanded="false"><span class="name">Home</span> <span class="caret"></span></a><ul role="menu"  class="dropdown-menu menu_2  first-child child-0 menu-item-id-4 menu-item-parent-2" ><li role="menuitem" class="nav-item    depth-1" data-item-id="4" ><a itemprop="url" data-item-id="4" class="menu_element_link nav-link   first-child child-0 menu-item-id-4 menu-item-parent-2 depth-1 nav-link px-3"  href="https://templates.microweber.com/banking/"><span>Home</span></a></li></ul></li></ul>
</div>
                    </div>
                </div>

                <div class="col-lg-4 col-12 d-flex order-2 order-xl-3 justify-content-lg-end justify-content-center my-md-0 my-1">
                    <ul class="nav nav-navbar align-items-center justify-content-md-end justify-content-center">
                                                   <li class="nav-item dropdown btn-contacts ps-3 my-xl-0 my-1">
        <div class="edit nodrop safe-mode" field="header_contact_us" rel="global">
            <div class='module module module-btn '   data-mw-title="Button" id="header-layout-btn"   button_style="btn-primary"   button_size="btn-sm px-4"   button_text="CONTACT US"   parent-module-id="header-layout"   parent-module="layouts"   data-type="btn"  >
    <a id="btn-header-layout-btn" href="#"  class="btn btn-primary btn-sm px-4">

        Sign In    </a>


    <style >
        #header-layout-btn {  }
        #header-layout-btn > #btn-header-layout-btn,#header-layout-btn > a, #header-layout-btn > button { background-color:#f5f6fb!important;color:#070f18!important;border-color:#f5f6fb!important;border-radius:10px!important;font-size: 19px!important;padding: .9em 2em!important; }
        #header-layout-btn > #btn-header-layout-btn:hover,#header-layout-btn > a:hover, #header-layout-btn > button:hover {  }

    </style>
</div>
        </div>
    </li>
                                                                          <li class="nav-item dropdown ps-3  my-xl-0 my-1">
        <div>
            <div class=' module module-multilanguage ' id='header-layout-multilanguage'  data-mw-title="Multilanguage" parent-module-id="header-layout"   parent-module="layouts"   data-type="multilanguage"  >    <style>
        .module-multilanguage-change-language .flag-icon {
            margin-right: 7px;
        }

        .module-multilanguage-change-language {
            display: inline-block;
        }
    </style>
</div>
        </div>
    </li>
                                                                   </ul>
                </div>
            </div>
        </div>
    </nav>
</section>




</div>
    </div>


<div class="edit main-content" data-layout-container rel="global" field="content">
    <div class=' module module-layouts ' id='module-layouts'  data-mw-title="Layouts" template="404"   data-type="layouts"   parent-module="layouts"   parent-module-id="module-layouts"  >

<section class="section  p-t-50 p-b-50  edit safe-mode" field="layout-404-module-layouts" rel="module">
    <div class="container">
        <div class="row">
            <div class="not_found_text col-4 align-self-center">
                <h1>Oops!</h1>
                <p class="my-3">A 404 error is a standard HTTP error
                 message code that means the website you
                  were trying to reach couldn't be found on the server.
                </p>
                <div class=' module module-btn ' id='module-layouts-btn'  data-mw-title="Button" button_size="px-6"   button_text="Go back"   parent-module-id="module-layouts"   parent-module="layouts"   data-type="btn"  >
    <a id="btn-module-layouts-btn" href="#"  class="btn btn-primary px-6">

        Go back    </a>


    <style >
        #module-layouts-btn {  }
        #module-layouts-btn > #btn-module-layouts-btn,#module-layouts-btn > a, #module-layouts-btn > button {  }
        #module-layouts-btn > #btn-module-layouts-btn:hover,#module-layouts-btn > a:hover, #module-layouts-btn > button:hover {  }

    </style>
</div>
            </div>

            <div class="col-8 text-center not_found_img">
                <img src="https://templates.microweber.com/banking/userfiles/templates/banking/assets/img/sections/404_graphic.png">
            </div>
        </div>
    </div>
</section>
</div>
</div>

    <div class=' module module-layouts '   data-mw-title="Layouts" template="footers/skin-29"   id="footer-layout"   template-filter="footers"   data-type="layouts"   parent-module="layouts"   parent-module-id="footer-layout"  >

<section class="  footer-skin-29 footer-background position-relative pt-10     edit safe-mode  " field="layout-footer-skin-29-footer-layout" rel="module" style="background-color: #191046!important;">
<!-- Footer -->

    <div class="col-xl-6 absolute-container position-xl-absolute p-8">

            <h1 class="text-center">Move even faster with Your <br> guide in the digital age.</h1>

            <div class="d-flex justify-content-center pt-5">
                <div class=' module module-btn ' id='footer-layout-btn'  data-mw-title="Button" text="Let`s Talk"   button_style="content-73-btn me-3"   parent-module-id="footer-layout"   parent-module="layouts"   data-type="btn"  >
    <a id="btn-footer-layout-btn" href="#"  class="btn content-73-btn me-3 ">

        Let`s Talk    </a>


    <style >
        #footer-layout-btn {  }
        #footer-layout-btn > #btn-footer-layout-btn,#footer-layout-btn > a, #footer-layout-btn > button {  }
        #footer-layout-btn > #btn-footer-layout-btn:hover,#footer-layout-btn > a:hover, #footer-layout-btn > button:hover {  }

    </style>
</div>
                <div class=' module module-btn ' id='footer-layout-btn--1'  data-mw-title="Button" text="Book Your Consultation"   button_style="content-73-btn-2"   parent-module-id="footer-layout"   parent-module="layouts"   data-type="btn"  >
    <a id="btn-footer-layout-btn--1" href="#"  class="btn content-73-btn-2 ">

        Book Your Consultation    </a>


    <style >
        #footer-layout-btn--1 {  }
        #footer-layout-btn--1 > #btn-footer-layout-btn--1,#footer-layout-btn--1 > a, #footer-layout-btn--1 > button {  }
        #footer-layout-btn--1 > #btn-footer-layout-btn--1:hover,#footer-layout-btn--1 > a:hover, #footer-layout-btn--1 > button:hover {  }

    </style>
</div>

            </div>

    </div>

    <div class="container-fluid pt-10 text-md-start text-center">
       <div class="row d-flex justify-content-center">

           <div class=" col-md-3 pr-md-8">
               <h6 class="mb-4">COMPANY INFO</h6>
               <p>Reach out to us anytime and lets create a better future for all technology users together, forever.
                   We are open to all types of collab offers and tons more.
               </p>

               <div class="d-flex align-items-center my-3">
                   <i class="mdi mdi-checkbox-marked-circle-outline me-4 d-block safe-element " style="color: #ffffff; font-size: 25px;"></i>

                  <div>
                      <p class="mb-0 footer-gray-text">Office Hours</p>
                      <p class="mb-0 footer-gray-text">Monady-Friday 9 AM-5 PM PST</p>
                  </div>
               </div>

               <div class="d-flex align-items-center my-3">
                   <i class="mdi mdi-checkbox-marked-circle-outline me-4 d-block safe-element " style="color: #ffffff; font-size: 25px;"></i>

                   <div>
                       <p class="mb-0 footer-gray-text">Support Hours</p>
                       <p class="mb-0 footer-gray-text">24/7 365</p>
                   </div>
               </div>
           </div>

           <div class="col-md-3 col-sm-12 col-xs-12">
                   <h6 class="mb-4">CONTACT INFO</h6>

                   <div class="d-flex align-items-center my-3">
                      <i class="mdi mdi-checkbox-marked-circle-outline me-4 d-block safe-element " style="color: #ffffff;  font-size: 25px;"></i>

                      <a href="mailto:info@techyessolutions.com">info@techyessolutions.com</a>
                  </div>

                   <div class="d-flex align-items-center my-3">
                       <i class="mdi mdi-checkbox-marked-circle-outline me-4 d-block safe-element " style="color: #ffffff;  font-size: 25px;"></i>
                       <p>858-227-4878</p>
                   </div>

           </div>

           <div class="row col-md-3 col d-lg-flex mt-md-0 mt-5">
               <h6 class="mb-4">OUR SERVICES</h6>
               <p class="footer-gray-text">Information Systems Strategy</p>
               <p class="footer-gray-text">Custom Software</p>
               <p class="footer-gray-text">Integration Services</p>
               <p class="footer-gray-text">Business Automation</p>
               <p class="footer-gray-text">Web, Ecommerce &amp; Mobiel Apps</p>
               <p class="footer-gray-text">Creative</p>

           </div>

           <div class="row col-md-3 col d-lg-flex mt-md-0 mt-5">
               <h6 class="mb-4">OUR LOCATIONS</h6>
               <img src="https://templates.microweber.com/banking/userfiles/templates/banking/assets/img/layouts/Techyes-map-01-3.png" class="content-73-image">
           </div>
       </div>
    </div>

    <script>
    AddToCartModalContent = window.AddToCartModalContent || function (title) {
        var html = ''
            + '<section style="text-align: center;">'
            + '<h5>' + title + '</h5>'
            + '<p>has been added to your cart</p><br />'
            + '<div><a href="javascript:;" onclick="mw.tools.modal.remove(\'#AddToCartModal\')" class="pull-left mt-2">Continue shopping</a>'
            + '<a href="https://templates.microweber.com/banking/contact-information" class="btn-d pull-right">Checkout</a></section><div class="clearfix"></div></div>';
        return html;

    }

    function cartModalBindButtons(step) {

        $('.js-show-step').off('click');
        $('.js-show-step').on('click', function () {
            var has_error = 0;
            var step = $(this).data('step');
            if (step == 'payment-method') {

                $('.js-delivery-address input').each(function () {
                    if (!this.checkValidity()) {
                        mw.notification.warning('Please fill the required fields');
                        // ..alert($(this).prop('name') + ' is not valid');
                        $(this).addClass('error');
                        has_error = 1;
                    } else {
                        $(this).removeClass('error');
                    }

                });

                if (has_error) {
                    step = 'delivery-address'
                }
            }

            $('.js-show-step').removeClass('active');

            $('[data-step]').removeClass('active');
            $('[data-step="' + step + '"]').addClass('active').parent().removeClass('muted');


            step1 = '.js-' + step;
            $('.js-step-content').hide();
            $(step1).show();
            $(this).addClass('active');
        });
    }

    $(document).ready(function () {
        mw.on('mw.cart.add', function (event, data) {
            $("#js-ajax-cart-checkout-process").reload_module()
            $(".bs-cart a").trigger('click');
            $("html, body").animate({ scrollTop: 0 }, "slow");
        });
    });
</script>


<!-- Login Modal -->
<div class="modal  login-modal" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="loginModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
            </div>

            <div class="modal-body">
                <div class="js-login-window">
                    <div class="icon"><i class="material-icons">person</i></div>

                    <div type="users/login" id="loginModalModuleLogin"></div>
                </div>

                <div class="js-register-window" style="display:none;">
                    <div class="icon"><i class="material-icons">exit_to_app</i></div>

                    <div type="users/register" id="loginModalModuleRegister"></div>

                    <p class="or"><span>or</span></p>

                    <div class="act login">
                        <a href="#" class="js-show-login-window"><span>Back to Login</span></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</section>

<section class="py-2" style="background-color: #191046;">
    <div class="container py-2">
        <div class="col-12 d-md-flex text-center">
            <small class="col-sm-6 text-md-start text-center edit" style="color: #ffffff;" field="footer-reserved-skin-13-footer-layout" rel="module">© All Rights Reserved. Your Website Design</small>
            <small class="col-sm-6 mb-0 noedit text-md-end text-center" style="color: #ffffff;"><span class="mw-powered-by"><a href="https://microweber.org/" title="Website Builder">Website Builder</a> by <a href="https://microweber.org" target="_blank" title="Make a website">Microweber</a></span></small>
        </div>
    </div>
</section>
</div>

</div>

<button id="to-top" class="btn btn-primary btn-square" style="display: block;"><i class="mdi mdi-arrow-up mdi-18px lh-1 m-0"></i></button>


<script src="https://templates.microweber.com/banking/userfiles/templates/banking/dist/main.min.js"></script>

<!-- Shopping Cart Modal -->
<div class="modal fade " id="shoppingCartModal" tabindex="-1" role="dialog" aria-labelledby="shoppingCartModalLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div type="shop/checkout" template="modal" id="js-ajax-cart-checkout-process" class="no-settings"></div>
    </div>
</div>



<script>
    AddToCartModalContent = window.AddToCartModalContent || function (title) {
        var html = ''
            + '<section style="text-align: center;">'
            + '<h5>' + title + '</h5>'
            + '<p>has been added to your cart</p><br />'
            + '<div><a href="javascript:;" onclick="mw.dialog.get(\'#AddToCartModal\').remove()" class="pull-left mt-2">Continue shopping</a>'
            + '<a href="https://templates.microweber.com/banking/contact-information" class="btn-d pull-right">Checkout</a></section><div class="clearfix"></div></div>';
        return html;
    }


    function cartModalBindButtons(step) {

        $('.js-show-step').off('click');
        $('.js-show-step').on('click', function () {
            var has_error = 0;
            var step = $(this).data('step');
            if (step == 'payment-method') {

                $('.js-delivery-address input').each(function () {
                    if (!this.checkValidity()) {
                        mw.notification.warning('Please fill the required fields');
                        // ..alert($(this).prop('name') + ' is not valid');
                        $(this).addClass('error');
                        has_error = 1;
                    } else {
                        $(this).removeClass('error');
                    }

                });

                if (has_error) {
                    step = 'delivery-address'
                }
            }

            $('.js-show-step').removeClass('active');

            $('[data-step]').removeClass('active');
            $('[data-step="' + step + '"]').addClass('active').parent().removeClass('muted');


            step1 = '.js-' + step;
            $('.js-step-content').hide();
            $(step1).show();
            $(this).addClass('active');
        });
    }


    $(document).ready(function () {
        mw.on('mw.cart.add', function (event, data) {
            $("#shoppingCartModal").modal();
            $("#js-ajax-cart-checkout-process").reload_module()

        });
    });
</script>

<script>
    $(document).ready(function () {

        $('#loginModal').on('show.bs.modal', function (e) {
            $('#loginModalModuleLogin').reload_module();
            $('#loginModalModuleRegister').reload_module();
        });


        $('#shoppingCartModal').on('show.bs.modal', function (e) {
            $('#js-ajax-cart-checkout-process').reload_module();
        });


        mw.on('mw.cart.add', function (event, data) {
            $('#shoppingCartModal').modal('show');


        });

        
        $('body').on('click', '.js-show-register-window', function (e) {
            $('#loginModal').modal('show');
            $('.js-login-window').hide();
            $('.js-register-window').show();
            e.preventDefault();
            e.stopPropagation();
        });

        $('.js-show-login-window').on('click', function (e) {

            $('.js-register-window').hide();
            $('.js-login-window').show();
            e.preventDefault();
            e.stopPropagation();
        });
    });
</script>




<!-- Login Modal -->
<div class="modal  login-modal" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="loginModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
            </div>

            <div class="modal-body">
                <div class="js-login-window">
                    <div class="icon"><i class="material-icons">person</i></div>

                    <div type="users/login" template="popup" id="loginModalModuleLogin"></div>
                </div>

                <div class="js-register-window" style="display:none;">
                    <div class="icon"><i class="material-icons">exit_to_app</i></div>

                    <div type="users/register" id="loginModalModuleRegister"></div>

                    <p class="or"><span>or</span></p>

                    <div class="act login">
                        <a href="#" class="js-show-login-window"><span>Back to Login</span></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



    <script>
        // collapse nav
        /*

 * CollapseNav.js - v1.0
 * jQuery Responsive Navigation
 * MIT License
 * by Petko Yovchevski

 Website: https://www.plumtex.com
 Docs: http://pyovchevski.github.io/collapse-nav
 Repo: https://github.com/PYovchevski/collapse-nav
 Issues: https://github.com/PYovchevski/collapse-nav/issues

 */

function collapseNav(selector, config) {
    var configuration = config;
    var navigation = selector;
    var original_navigation = $(selector).html();

    $(navigation).addClass('collapseNav-not-initialized');

    function init(selector, config) {
        var navigation = selector;

        $(navigation).removeClass('collapseNav-not-initialized');
        $(navigation).addClass('collapseNav-initialized')

        var responsive = config.responsive;
        if (!responsive) {
            responsive = 1;
        }

        var mobile_break = config.mobile_break;
        if (!mobile_break) {
            mobile_break = 992;
        }

        var li_class = config.li_class;
        if (!li_class && li_class != '') {
            li_class = 'dropdown';
        }

        var li_a_class = config.li_a_class;
        if (!li_a_class && li_a_class != '') {
            li_a_class = 'dropdown-toggle';
        }

        var li_ul_class = config.li_ul_class;
        if (!li_ul_class && li_ul_class != '') {
            li_ul_class = 'dropdown-menu';
        }

        var more_text = config.more_text;
        if (!more_text) {
            more_text = 'More';
        }

        var caret = config.caret;
        if (!caret && caret != '') {
            caret = '<span class="caret"></span>';
        }

        var ul_width = $(navigation).outerWidth();
        var li_width;
        var possible_buttons;
        var li_count;

        //console.log('ul: ' + ul_width);

        /*---------------------------------------
         --- Check base buttons to navigation  ---
         --------------------------------------*/
        li_width = 0;
        possible_buttons = 0;
        li_count = 0;

        $(navigation).children("li").each(function (i) {
            li_count = li_count + 1;
            li_width = li_width + $(this).outerWidth(true);

            //console.log(li_count + ' li ' + $(this).text() + ': ' + li_width);

            if (ul_width >= li_width) {
                possible_buttons = possible_buttons + 1;
            }
        });

        // The navigation does not need a More menu, then stop the script
        if (li_count <= possible_buttons) {
            return;
        }

        //console.log('Possible buttons: ' + possible_buttons);


        /*-------------------------------------------
         --- Check the more buttons to navigation ---
         ------------------------------------------*/
        li_width = 0;
        possible_buttons = 0;
        li_count = 0;

        //The More Button Width
        $(navigation).children().first().clone().appendTo(navigation);
        $(navigation).children().last().find('a').html(more_text + ' ' + caret).css({'vissibility': 'hidden'});
        var the_more_button_width = $(navigation).children().last();

        li_count = li_count + 1;
        li_width = li_width + the_more_button_width.outerWidth(true);
        //console.log(li_count + ' li More: ' + li_width);
        the_more_button_width.remove();

        $(navigation).children("li").each(function (i) {
            li_count = li_count + 1;
            li_width = li_width + $(this).outerWidth(true);

            //console.log(li_count + ' li ' + $(this).text() + ': ' + li_width);

            if (ul_width >= li_width) {
                possible_buttons = possible_buttons + 1;
            }
        });

        //console.log('Possible buttons: ' + (possible_buttons + 1) + ' + More button');

        /*------------------
         --- Some checks ---
         -----------------*/

        if (responsive == 1) {
            number_of_buttons = possible_buttons;
        } else {
            var number_of_buttons = config.number_of_buttons;
            if (!number_of_buttons) {
                number_of_buttons = 4;
            }
        }
        //console.log('Number of buttons: ' + number_of_buttons);

        if ($(window).width() < mobile_break) {
            return;
        }

        /*----------------------------------------
         --- Convert the navigation to the new ---
         ----------------------------------------*/
        var btn_n = 0;
        var ul = '<ul class="' + li_ul_class + '">'
        $(navigation).children("li").each(function (i) {
            btn_n = btn_n + 1;

            if (btn_n > number_of_buttons) {
                //console.log(btn_n + ' > ' + number_of_buttons);

                ul += this.outerHTML;
            }
        })
        ul += '</ul>';

        number_of_buttons = number_of_buttons - 1;
        $(navigation).children("li:gt(" + number_of_buttons + ")").remove();
        $(navigation).append('<li class="' + li_class + '"><a href="javascript:;" class="' + li_a_class + '" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">' + more_text + caret + '</a>' + ul + '</li>')
    }

    $(window).on('load', function () {
        if ($(window).width() >= configuration.mobile_break) {
            $(navigation).html(original_navigation);
        }
        init(navigation, configuration);
        // init(selector, config);
    });

    $(window).on('resize collapseNavReInit', function () {
        if ($(window).width() >= configuration.mobile_break) {
            $(navigation).html(original_navigation);
        }
        init(navigation, configuration);
    });

    window.addEventListener("orientationchange", function () {
        if ($(window).width() >= configuration.mobile_break) {
            $(navigation).html(original_navigation);
        }
        init(navigation, configuration);
    }, false);

    init(navigation, configuration);
}

$.fn.collapseNav = function (config) {
    config = config || {}

    var defaults = {
        responsive: 1, //Automatically count the possible buttons in the navigation
        number_of_buttons: 4, //Allowable number of buttons in the navigation. Works only if 'responsive' = 0
        more_text: mw.lang('More'), //The text on the Drop Down Button
        mobile_break: 992, //With this resolution and higher the script will be init
        li_class: 'dropdown',
        li_a_class: 'dropdown-toggle',
        li_ul_class: 'dropdown-menu',
        caret: '<span class="caret"></span>' //Element append immediately after the More text
    }

    var settings = $.extend({}, defaults, config)

    return this.each(function () {
        setTimeout(function (scope) {
            collapseNav(scope, settings);
        }, 700, this);
    })
}
    </script>


    <style>
        // collapse nav
        /*

 * CollapseNav.js - v1.0
 * jQuery Responsive Navigation
 * MIT License
 * by Petko Yovchevski

 Website: https://www.plumtex.com
 Docs: http://pyovchevski.github.io/collapse-nav
 Repo: https://github.com/PYovchevski/collapse-nav
 Issues: https://github.com/PYovchevski/collapse-nav/issues

 */

.collapse-nav {
    overflow: hidden;
    background-color: #2b2b2b;
}

.collapse-nav li {
    float: left;
    list-style-type: none;
    margin: 0;
}

.collapse-nav li a {
    font-size: 16px;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    display: block;
    border: 0;
    cursor: pointer;
}

.collapse-nav ul.dropdown {
    float: left;
    overflow: hidden;
}

.collapse-nav ul.dropdown a.dropdown-toggle {
    font-size: 16px;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    display: block;
}

.collapse-nav li:hover > a,
.collapse-nav .dropdown:hover > .dropdown-toggle {
    background-color: red;
}

.collapse-nav ul.dropdown-menu {
    display: none;
    position: absolute;
    background-color: #2b2b2b;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
    z-index: 1;
}

.collapse-nav ul.dropdown-menu .dropdown-menu {
    top: 0;
    bottom: 0;
    right: auto;
    left: 100%;
    margin: 0;
}

.collapse-nav .dropdown-menu li {
    float: none;
    margin: 0;
}

.collapse-nav .dropdown-menu li a {
    color: #fff;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
    background: #2b2b2b;
}

.collapse-nav .dropdown-menu a:hover {
    background-color: #fff;
    color: #2b2b2b;
}

.collapse-nav .dropdown:hover > .dropdown-menu {
    display: block;
}

.collapse-nav .caret {
    display: inline-block;
    transition: all .3s;
    transform: rotate(0);
    width: 0;
    height: 0;
    vertical-align: middle;
    border-top: 4px dashed;
    border-top: 4px solid \9;
    border-right: 4px solid transparent;
    border-left: 4px solid transparent;
    margin-inline-start: 5px;
}

.collapse-nav:not(.collapseNav-initialized) li {
    opacity: 0 !important;
    visibility: hidden !important;
    position: absolute !important;
    transition: none !important;
    -webkit-transition: none !important;
    -moz-transition: none !important;
}

.collapse-nav:not(.collapseNav-initialized) li:first-child {
    opacity: 1 !important;
    visibility: visible !important;
    position: relative !important;
    transition: none !important;
    -webkit-transition: none !important;
    -moz-transition: none !important;
}

.collapseNav-not-initialized li {
    opacity: 0 !important;
    visibility: hidden !important;
    position: absolute !important;
    transition: none !important;
    -webkit-transition: none !important;
    -moz-transition: none !important;
}

.collapseNav-not-initialized li:first-child {
    opacity: 1 !important;
    visibility: visible !important;
    position: relative !important;
    transition: none !important;
    -webkit-transition: none !important;
    -moz-transition: none !important;
}
    </style>

<script async defer type="text/javascript" src="https://templates.microweber.com/banking/userfiles/cache/apijs/ping.2568495471.1.3.1.js"></script></body>
</html>
